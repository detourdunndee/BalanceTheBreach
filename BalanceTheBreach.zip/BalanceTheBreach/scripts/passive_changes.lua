----- Flame Shielding -----
-- Base cost reduced to Free from 1 --
Passive_FlameImmune.PowerCost = 0

----- Storm Generator -----
-- Base cost reduced to Free from 1 --
Passive_Electric.PowerCost = 0

----- Viscera Nanobots -----
-- Base cost reduced to Free from 1 --
Passive_Leech.PowerCost = 0

----- Networked Armor -----
-- Upgrade 1 (+1 Health) cost reduced to 1 from 2 --
Passive_Defenses.UpgradeCost = {1}

----- Repair Field -----
-- Base cost reduced to Free from 1 --
Passive_MassRepair.PowerCost = 0

----- Stabilizers -----
-- Base cost reduced to Free from 1 --
Passive_Burrows.PowerCost = 0

----- Psionic Receiver -----
-- Base cost reduced to Free from 1 --
Passive_Psions.PowerCost = 0

----- Kickoff Boosters -----
-- Upgrade 1 (+1 Movement) cost reduced to 1 from 2 --
Passive_Boosters.UpgradeCost = {1}

----- Medical Supplies -----
-- Base cost reduced to Free from 1 --
Passive_Medical.PowerCost = 0

----- Vek Hormones -----
-- Base cost reduced to 1 from Free --
-- Upgrade 2 (+1 Damage) cost reduced to 1 from 2 --
Passive_FriendlyFire.PowerCost = 0
Passive_FriendlyFire.UpgradeCost = {1,1}

----- Critical Shields -----
-- Base cost reduced to Free from 1 --
Passive_CritDefense.PowerCost = 0
