----- Gana -----
-- Power cost reduced to Free from 1 --
Pilot_Warrior.PowerCost = 0