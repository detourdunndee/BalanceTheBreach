local weaponTexts = {


Prime_Rockmech_Upgrade1 = "Flaming Rock",
Prime_Rockmech_A_UpgradeDescription = "Collision tile is lit on Fire.",

Prime_RightHook_Upgrade1 = "+1 Range",
Prime_RightHook_Upgrade2 = "+2 Damage",
Prime_RightHook_A_UpgradeDescription = "Take an extra step before attacking.",
Prime_RightHook_B_UpgradeDescription = "Increases damage by 2.",

Prime_Flamethrower_Upgrade2 = "+1 Damage",
Prime_Flamethrower_B_UpgradeDescription = "Increases damage by 1 to lit enemies.",

Prime_Areablast_Description = "Blast all adjacent tiles before leaping.", 
Prime_Areablast_Upgrade1 = "+1 Range",
Prime_Areablast_Upgrade2 = "+1 Damage",
Prime_Areablast_A_UpgradeDescription = "Increases potential movement range by 1",
Prime_Areablast_B_UpgradeDescription = "Increases damage by 1.",

Prime_Shift_Upgrade1 = "Toss++",
Prime_Shift_A_UpgradeDescription = "Increases the toss range to map wide.",

Prime_Sword_Upgrade2 = "+1 Damage",
Prime_Sword_B_UpgradeDescription = "Increases damage on each affected tile by 1.",
 
Brute_Tankmech_Upgrade1 = "Phasers",
Brute_Tankmech_Upgrade2 = "+2 Damage",
Brute_Tankmech_A_UpgradeDescription = "Shoot a projectile that phases through objects.",
Brute_Tankmech_B_UpgradeDescription = "Increases damage by 2.",

Brute_Jetmech_Upgrade1 = "+1 Range",
Brute_Jetmech_Upgrade2 = "+1 Damage",
Brute_Jetmech_A_UpgradeDescription = "Allows jumping over and attacking an additional target.",
Brute_Jetmech_B_UpgradeDescription = "Increases damage by 1.",

Brute_PhaseShot_Upgrade2 = "+2 Damage",
Brute_PhaseShot_B_UpgradeDescription = "Increases damage by 2.",

Brute_Heavyrocket_Upgrade2 = "+1 Damage",
Brute_Heavyrocket_B_UpgradeDescription = "Increases damage by 1.",

Brute_Bombrun_Upgrade2 = "Chemical Bombs",
Brute_Bombrun_B_UpgradeDescription = "Equip bombs that cause A.C.I.D and Fire, but no damage.",

Ranged_Rockthrow_Upgrade1 = "Backrest",
Ranged_Rockthrow_Upgrade2 = "+2 Damage",
Ranged_Rockthrow_A_UpgradeDescription = "Raise a rock from the ground behind the Mech if the tile is empty.",
Ranged_Rockthrow_B_UpgradeDescription = "Increases damage by 2.",

Ranged_RainingVolley_Upgrade2 = "+1 Damage",
Ranged_RainingVolley_B_UpgradeDescription = "Increases damage by 1.",

Science_Pullmech_Upgrade1 = "Shield Self",
Science_Pullmech_A_UpgradeDescription = "Creates a personal Shield when used.",

Science_Repulse_Upgrade1 = "Shield Friendly",
Science_Repulse_Upgrade2 = "",
Science_Repulse_A_UpgradeDescription = "Shield adjacent ally or Building.",
Science_Repulse_B_UpgradeDescription = "",

Science_Shield_Upgrade1 = "Shield Self",
Science_Shield_A_UpgradeDescription = "Creates a personal Shield when used.",

Science_FireBeam_Upgrade1 = "Unlimited Use",
Science_FireBeam_A_UpgradeDescription = "Removes use restriction in battles.",

Support_Refrigerate_Upgrade1 = "Unlimited Use",
Support_Refrigerate_A_UpgradeDescription = "Removes use restriction in battles",
}

return weaponTexts