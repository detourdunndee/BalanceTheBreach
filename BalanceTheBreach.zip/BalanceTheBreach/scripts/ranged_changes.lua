----- Rock Accelerator -----
-- Added 2nd upgrade where previously there was none --
Ranged_Rockthrow = ArtilleryDefault:new{-- LineArtillery:new{
	Class = "Ranged",
	Icon = "weapons/ranged_rockthrow.png",
	Sound = "",
	ArtilleryStart = 2,
	ArtillerySize = 8,
	Explosion = "",
	PowerCost = 1,
	BounceAmount = 1,
	Damage = 2,
	Backhit = 0,
	LaunchSound = "/weapons/boulder_throw",
	ImpactSound = "/impact/dynamic/rock",
	Upgrades = 2,
	Push = false,
	UpgradeCost = {1,3},
	--UpgradeList = { "+1 Damage" },
	TipImage = {
		Unit = Point(2,3),
		Enemy = Point(2,1),
		Enemy2 = Point(3,1),
		Target = Point(2,1)
	}
}
					
function Ranged_Rockthrow:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	local damage = SpaceDamage(p2, self.Damage)

	if Board:IsValid(p2) and not Board:IsBlocked(p2,PATH_PROJECTILE) then
		damage.sPawn = "RockThrown"
		damage.sAnimation = ""
		damage.iDamage = 0
	else 
		damage.sAnimation = "rock1d" 
	end

	
	
	ret:AddBounce(p1, 1)

	if self.Backhit == 1 and not Board:IsBlocked(p1 - DIR_VECTORS[dir], 0) then 
	local rock = SpaceDamage(p1 - DIR_VECTORS[dir], 0)
	rock.sPawn = "RockThrown"
	ret:AddDamage(rock)
	end

	ret:AddArtillery(damage,"effects/shotdown_rock.png")

	ret:AddBounce(p2, self.BounceAmount)
	ret:AddBoardShake(0.15)
	
	local damagepush = SpaceDamage(p2 + DIR_VECTORS[(dir+1)%4], 0, (dir+1)%4)
	damagepush.sAnimation = "airpush_"..((dir+1)%4)
	ret:AddDamage(damagepush) 
	damagepush = SpaceDamage(p2 + DIR_VECTORS[(dir-1)%4], 0, (dir-1)%4)
	damagepush.sAnimation = "airpush_"..((dir-1)%4)
	

	ret:AddDamage(damagepush)
	
	
	return ret
end

Ranged_Rockthrow_A = Ranged_Rockthrow:new{
	Backhit = 1,
	BounceAmount = 3
} 
Ranged_Rockthrow_B = Ranged_Rockthrow:new{
	Damage = 4,
	BounceAmount = 3
} 
Ranged_Rockthrow_AB = Ranged_Rockthrow:new{
	Damage = 4,
	Backhit = 1,
	BounceAmount = 4
}

----- Cluster Artillary -----
-- Upgrade 1 cost reduced to 1 from 2 --
-- Upgrade 2 cost increased to 3 from 2 --
Ranged_Defensestrike.UpgradeCost = {1,3}

----- Micro Artillary -----
Ranged_ScatterShot.UpgradeCost = {1,3}

----- Aegon Mortar -----
-- Upgrade 1 cost increased to 2 from 1 --
Ranged_BackShot.UpgradeCost = {2,2}

----- Cryo-Launcher -----
-- Base cost reduced to 1 from 2 --
Ranged_Ice.PowerCost = 1
	
----- Burning Mortar -----
-- Upgrade 1 cost reduced to 1 from 2 --
Ranged_Fireball.UpgradeCost = {1}

----- Raining Death -----
-- Base damage (of final tile) increased to 3 from 2
-- Upgrade 1 cost reduced to 1 from 2 --
-- Upgrade 2 no longer adds self damage, affects entire line, and cost increased to 3 from 2 --
Ranged_RainingVolley.UpgradeCost = {1,3}
Ranged_RainingVolley.Damage = 3
Ranged_RainingVolley_B = Ranged_RainingVolley:new{
	Damage = 4,
	LineDamage = 2,
	SelfDamage = 1,
}			
Ranged_RainingVolley_AB = Ranged_RainingVolley:new{
	Damage = 4,
	LineDamage = 2,
	SelfDamage = 1,
	BuildingDamage = false
}
----- Heavy Artillery -----
-- Upgrade 2 increased to 3 from 2 --
Ranged_Wide.UpgradeCost = {1,3}

----- Gemeni Missiles -----
-- Upgrade 2 cost increased to 2 from 1 --
Ranged_Dual.UpgradeCost = {1,2}