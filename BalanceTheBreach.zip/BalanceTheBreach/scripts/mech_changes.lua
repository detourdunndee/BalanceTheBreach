-- Hook Mech MoveSpeed increased to 4 from 3 --
WallMech.MoveSpeed = 4

-- Leap Mech MoveSpeed decreased to 3 from 4 --
LeapMech.MoveSpeed = 3

-- Moved passives to the Prime Mechs --
RocketMech.SkillList = { "Ranged_Rocket" }
JetMech.SkillList = { "Brute_Jetmech", "Passive_Electric" }

JudoMech.SkillList = { "Prime_Shift" , "Passive_FriendlyFire" }
GravMech.SkillList = { "Science_Gravwell" }

LeapMech.SkillList = { "Prime_Leap" , "Passive_Leech" }
NanoMech.SkillList = { "Science_AcidShot" }
