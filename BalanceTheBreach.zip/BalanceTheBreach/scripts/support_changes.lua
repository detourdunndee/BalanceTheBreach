----- Smoke Bombs -----
-- Base cost increased to 1 from Free --
Support_Smoke.PowerCost = 1

----- Heat Converter -----
-- Base cost increased to 2 from 1
-- Upgrade 1 changed to Unlimited Use, and cost increased to 2 from 1 --
Support_Refrigerate.PowerCost = 2
Support_Refrigerate.UpgradeCost = {2}
Support_Refrigerate_A.Limited = 0 

----- Targeted Strike -----
-- Base cost increased to 3 -- 
-- Damage increased to 5 --
Support_Force.PowerCost = 3 
Support_Force.Damage = 5

----- Missile Barrage -----
-- Upgrade 1 cost increased to 3 from 2 --
Support_Missiles.UpgradeCost = {3}

----- Storm Surge -----
-- Base cost increased to 2 from 1 --
-- Upgrade (Unlimited Uses) cost increased to 2 from 1 --
Support_Wind.PowerCost = 2
Support_Wind.UpgradeCost = {2}

----- Ice Generator -----
-- Upgrade 1 cost increased to 2 from 1 --
Support_Blizzard.UpgradeCost = {2,2}