----- Titan Fist ------
-- Upgrade 1 cost reduced to 1 from 2 --
Prime_Punchmech.UpgradeCost = {1,3}

----- Electric Whip -----
-- Base cost reduced to 1 from 2 --
Prime_Lightning.PowerCost = 1

----- Rock Launcher-----
-- Upgrade 1 chaned to flaming rock for 1 cost --
Prime_Rockmech.UpgradeCost = {2,2}
function Prime_Rockmech:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
			
	local target = p1 + DIR_VECTORS[dir]
	local spawnRock = Point(-1,-1)
	
	for i = 1, 8 do
		--target.x == p2. and target.y == p2.y
		if Board:IsBlocked(target,PATH_PROJECTILE) then
			local hitdamage = SpaceDamage(target, self.Damage)

			if self.Fire == 1 then
			hitdamage.iFire = self.Fire
			end

			if self.Push == 1 then
				hitdamage = SpaceDamage(target, self.Damage, dir)
			end
		
			if target - DIR_VECTORS[dir] ~= p1 then
			    spawnRock = target - DIR_VECTORS[dir]
				hitdamage.sAnimation = "ExploAir1"
			else
				hitdamage.sAnimation = "rock1d" 
			end
			

			ret:AddProjectile(hitdamage,"effects/shot_mechrock")
			break
		end
		
		if target == p2 then
			spawnRock = target
			ret:AddProjectile(SpaceDamage(spawnRock),"effects/shot_mechrock")
			break
		end
		
		if not Board:IsValid(target) then
			spawnRock = target - DIR_VECTORS[dir]
			ret:AddProjectile(SpaceDamage(spawnRock),"effects/shot_mechrock")
			break
		end
		
		target = target + DIR_VECTORS[dir]
	end
	
	if Board:IsValid(spawnRock) then
		local damage = SpaceDamage(spawnRock)
		damage.sPawn = "RockThrown"

		ret:AddDamage(damage)
		target = spawnRock	
	end
	
	--ret.path = Board:GetSimplePath(p1, target)
	
	return ret
end

Prime_Rockmech_A = Prime_Rockmech:new{
	Fire = 1,
}
Prime_Rockmech_B = Prime_Rockmech:new{
	Damage = 3
}		
Prime_Rockmech_AB = Prime_Rockmech:new{
	Fire = 1,
	Damage = 3
}	

----- Sidewinder Fist -----
-- Range bonus moved from just AB to A and AB --
-- Upgrade 2 damage increased to 3 from 2 for 3 cost --
Prime_RightHook.UpgradeCost = {1,3}
Prime_RightHook_A = Prime_RightHook:new{
	PathSize = 2,
	Range = 2, 
	TipImage = {
		Unit = Point(2,3),
		Enemy = Point(2,1),
		Target = Point(2,1)
	}
}
Prime_RightHook_B = Prime_RightHook:new{	
	Damage = 4, 
}
Prime_RightHook_AB = Prime_RightHook:new{
	PathSize = 2, 
	Range = 2,
	Damage = 4,
	TipImage = {
		Unit = Point(2,3),
		Enemy = Point(2,1),
		Target = Point(2,1)
	}
}
-----  Rocket Fist -----
-- Upgrade 1 cost reduced to 1 from 2 --
-- Upgrade 2 cost increased to 3 from 2 --
Prime_RocketPunch.UpgradeCost = {1,3}

----- Vice Fist -----
-- Base cost increased to 1 from Free --
-- THROWING INTENSIFIES -- 
-- All credit to reddit user greenmajesti aka subset forum user neozoid for function changes --
Prime_Shift.PowerCost = 1
Prime_Shift.Range = 1
Prime_Shift.TipImage = {
	Unit = Point(2,1),
	Target = Point(2,2),
  	Enemy = Point(2,0),
	}

function Prime_Shift:GetTargetArea(p1)
local ret = PointList()
  for dir = DIR_START, DIR_END do
    local curr = p1 - DIR_VECTORS[dir]
    if Board:IsPawnSpace(curr) and not Board:GetPawn(curr):IsGuarding() then
    for i = 1, self.Range do
      local curr = p1 + DIR_VECTORS[dir]*i
      if not Board:IsBlocked(curr, PATH_FLYER) then
      ret:push_back(curr)
      end
    end
    end
  end
return ret
end

function Prime_Shift:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
  local target = p1+DIR_VECTORS[(direction+2)%4]

  ret:AddMelee(p1,SpaceDamage(target,0))
  local move = PointList()
  move:push_back(p1-DIR_VECTORS[direction])
  move:push_back(p2)
  ret:AddLeap(move, FULL_DELAY)
  ret:AddDamage(SpaceDamage(p2,self.Damage))
  ret:AddBounce(p2,3)

	return ret
end

Prime_Shift_A = Prime_Shift:new{
	Damage = 1,
  	Range = 8,
	TipImage = {
	Unit = Point(2,1),
	Target = Point(2,4),
  	Enemy = Point(2,0),
	}
}
Prime_Shift_B = Prime_Shift:new{
	Damage = 3,
	Range = 8,
	TipImage = {
	Unit = Point(2,1),
	Target = Point(2,2),
  	Enemy = Point(2,0),
	}
}
Prime_Shift_AB = Prime_Shift:new{
	Damage = 3,
	Range = 8,
	TipImage = {
	Unit = Point(2,1),
	Target = Point(2,4),
  	Enemy = Point(2,0),
	}
}

----- Prime Flamethrower -----
-- Base range increased to 2 from 1 --
-- Upgrade 2 changed to 1 damage --
Prime_Flamethrower.Range = 2
Prime_Flamethrower.UpgradeCost = {1,3}
Prime_Flamethrower.TipImage = StandardTips.Ranged
Prime_Flamethrower_A = Prime_Flamethrower:new{
	PathSize = 3, 
	Range = 3,
	TipImage = {
	Unit = Point(2,4),
	Enemy = Point(2,1),
	Target = Point(2,1)
	}
}
Prime_Flamethrower_B = Prime_Flamethrower:new{
	Damage = 3,
	FireDamage = 3,
	TipImage = StandardTips.Ranged
}
Prime_Flamethrower_AB = Prime_Flamethrower:new{
	Damage = 3,
	FireDamage = 3,
	PathSize = 3, 
	Range = 3,
	TipImage = {
	Unit = Point(2,4),
	Enemy = Point(2,1),
	Target = Point(2,1)
	}
}

----- Area Blast -----
-- I probably did a real hack job on this one --
-- Given a Leap function, and upgrades rebalanced --

Prime_Areablast = Skill:new{
	Class = "Prime",
	Icon = "weapons/prime_areablast.png",	
	Rarity = 1,
	Range = 2,
	MinMove = 2,
	Cost = "med",
	Cost = 1,
	Damage = 1,
	Push = 0,
	PushAnimation = 0, -- 0 = airpush; 1 = explopush1; 2 = explopush2
	Limited = 0,
	PowerCost = 1,
	Upgrades = 2,
	UpgradeCost = {1,3},
	LaunchSound = "/weapons/localized_burst",
	ImpactSound = "/impact/generic/mech",
	TipImage = {
		Unit = Point(2,2),
		Target = Point(0,2),
		Building = Point(1,2),
		Enemy = Point(2,3),
		Enemy2 = Point(3,2),
		Enemy3 = Point(2,1)
		}
}

function Prime_Areablast:GetTargetArea(point)
	local ret = PointList()
	
	for i = DIR_START, DIR_END do
		for k = 1, self.Range do
			local curr = DIR_VECTORS[i]*k + point
			if Board:IsValid(curr) and not Board:IsBlocked(curr, Pawn:GetPathProf()) then
				ret:push_back(DIR_VECTORS[i]*k + point)
			end
		end
	end
	
	return ret
end

function Prime_Areablast:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	
	for i = DIR_START,DIR_END do
		local spaceDamage = SpaceDamage(p1 + DIR_VECTORS[i], self.Damage)	
		spaceDamage.sSound = "/impact/generic/explosion"
		spaceDamage.sAnimation = "explopush1_"..i
		ret:AddDamage(spaceDamage)
	end
	
	local move = PointList()
	move:push_back(p1)
	move:push_back(p2)
	
	ret:AddBurst(p1,"Emitter_Burst_$tile",DIR_NONE)
	ret:AddLeap(move, FULL_DELAY)
	ret:AddBurst(p2,"Emitter_Burst_$tile",DIR_NONE)
	return ret
end	

Prime_Areablast_A = Prime_Areablast:new{
		Range = 3,
}

Prime_Areablast_B = Prime_Areablast:new{
		Damage = 2
}

Prime_Areablast_AB = Prime_Areablast:new{
		Range = 3,
		Damage = 2,
}

----- Prime Spear -----
-- Base cost reduced to 1 from 2 --
-- Upgrade 2 cost increased to 3 from 2 --
Prime_Spear.PowerCost = 1
Prime_Spear.UpgradeCost = {1,3}
	
----- Vortex Fist -----
-- Base self damage reduced to 1 from 2 --
Prime_SpinFist.SelfDamage = 1
Prime_SpinFist_A.SelfDamage = 0
Prime_SpinFist_AB.SelfDamage = 0


----- Titan Sword -----
-- Upgrade 2 (+2 Damage) reduced to 1 --
Prime_Sword_B.Damage = 3
Prime_Sword_AB.Damage = 3

----- Mercury Fist -----
-- Base cost increased to 2 from 1 --
-- Upgrade 1 reduced to 1 from 2 --
-- Upgrade 2 increased to 2 from 1 --
Prime_Smash.PowerCost = 2
Prime_Smash.UpgradeCost = {1,2}