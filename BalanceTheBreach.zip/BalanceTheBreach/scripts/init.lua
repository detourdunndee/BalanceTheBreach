local function init(self)
    require(self.scriptPath.."prime_changes")
    require(self.scriptPath.."brute_changes")
    require(self.scriptPath.."ranged_changes")
    require(self.scriptPath.."science_changes")
    require(self.scriptPath.."support_changes")
    require(self.scriptPath.."passive_changes")
    require(self.scriptPath.."mech_changes")
    require(self.scriptPath.."pilot_changes")
    modApi:addWeapon_Texts(require(self.scriptPath.."text_changes"))
end

local function load(self,options,version)
end

return {
    id = "Balance the Breach",
    name = "Balance the Breach",
    version = "Season 1",
    init = init,
    load = load
}
