----- Taurus Cannon -----
-- Upgrade 1 changed to Phase Shot --
-- Upgrade 2 damage increased to 2 and cost increased to 3 --
Brute_Tankmech.Phase = false
Brute_Tankmech.UpgradeCost = {1,3}
Brute_Tankmech_A = Brute_Tankmech:new{
	Phase = true,
	ProjectileArt = "effects/shot_phaseshot",
	TipImage = {
		Unit = Point(2,3),
		Building = Point(2,2),
		Enemy = Point(2,1),
		Target = Point(2,2)
	}
}

Brute_Tankmech_B = Brute_Tankmech:new{
	Damage = 3
}

Brute_Tankmech_AB = Brute_Tankmech:new{
	Phase = true,
	Damage = 3,
	Explo = "explopush2_",
	ProjectileArt = "effects/shot_phaseshot",
	TipImage = {
		Unit = Point(2,3),
		Building = Point(2,2),
		Enemy = Point(2,1),
		Target = Point(2,2)
	}
}

----- Janus Cannon -----
-- Upgrade 1 cost increased to 2 from 1 --
-- Upgrade 2 cost decreased from 3 to 2 --
Brute_Mirrorshot.UpgradeCost = {2,2}

----- Phase Cannon -----
-- Upgrade 1 cost reduced to 1 from 2 --
-- Upgrade 2 damage increased to 2 from 1, and cost increased to 3 from 2
Brute_PhaseShot.UpgradeCost = {1,3}
Brute_PhaseShot_B.Damage = 3
Brute_PhaseShot_AB.Damage = 3

----- Grappling Hook -----
-- Base cost increased to 1 from free --
Brute_Grapple.PowerCost = 1

----- Shock Cannon -----
-- Base cost reduced to 1 from 2 --
-- Upgrade 1 cost increased to 2 from 1 --
Brute_Shockblast.PowerCost = 1
Brute_Shockblast.UpgradeCost = {2,2}
	
----- Ramming Engines -----
-- Upgrade 2 cost reduced to 2 from 3 --
Brute_Beetle.UpgradeCost = {1,2}

----- Unstable Cannon -----
-- Upgrade 2 cost reduced to 2 from 3 --
Brute_Unstable.UpgradeCost = {1,2}

----- Heavy Rocket -----
-- Base cost increased to 2 from 1 --
-- Base damage increased to 4 from 3 --
-- Upgrade 2 damage decreased to 1 from 2 --
Brute_Heavyrocket.Damage = 4
Brute_Heavyrocket.PowerCost = 2
Brute_Heavyrocket_B.Damage = 5
Brute_Heavyrocket_AB.Damage = 5

----- Shrapnel Cannon -----
-- Upgrade 2 cost increased to 3 from 2 --
Brute_Splitshot.UpgradeCost = {1,3}

----- Astra Bombs -----
-- Reworked to provide Fire and Acid support instead of damage --
-- Many thanks to Lemonymous for showing me the way because oh God I have no idea what I'm doing sometimes--
Brute_Bombrun = Skill:new{
	Class = "Brute",
	Icon = "weapons/brute_bombrun.png",
	Rarity = 3,
	AttackAnimation = "ExploRaining1",
	Sound = "/general/combat/stun_explode",
	MinMove = 2,
	Range = 8,
	Damage = 1,
	AnimDelay = 0.2,
	Acid = 0,
	Fire = 0,
	Limited = 1,
	PowerCost = 1,
	DoubleAttack = 0, --does it attack again after stopping moving
	Upgrades = 2,
	UpgradeCost = {1,3},
	LaunchSound = "/weapons/bomb_strafe",
	BombSound = "/impact/generic/explosion",
	TipImage = {
		Unit = Point(2,4),
		Enemy = Point(2,2),
		Target = Point(2,0)
	}
}
function Brute_Bombrun:GetTargetArea(point)
	local ret = PointList()
	for i = DIR_START, DIR_END do
		for k = self.MinMove, self.Range do
			if not Board:IsBlocked(DIR_VECTORS[i]*k + point, Pawn:GetPathProf()) then
				ret:push_back(DIR_VECTORS[i]*k + point)
			end
		end
	end
	return ret
end
function Brute_Bombrun:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local dir = GetDirection(p2 - p1)
	
	local move = PointList()
	move:push_back(p1)
	move:push_back(p2)
	
	local distance = p1:Manhattan(p2)
	
	ret:AddBounce(p1,2)
	if distance == 1 then
		ret:AddLeap(move, 0.5)--small delay between move and the damage, attempting to make the damage appear when jet is overhead
	else
		ret:AddLeap(move, 0.25)
	end
		
	for k = 1, (self.Range-1) do
		
		if p1 + DIR_VECTORS[dir]*k == p2 then
			break
		end
		
		local damage = SpaceDamage(p1 + DIR_VECTORS[dir]*k, self.Damage)
		
		damage.iFire = self.Fire
		
		if Board:IsPawnSpace(damage.loc) then
  		damage.iAcid = self.Acid
		else damage.iAcid = 0
		end
		
		damage.sAnimation = self.AttackAnimation
		damage.sSound = self.BombSound
		
		if k ~= 1 then
			ret:AddDelay(self.AnimDelay) --was 0.2
		end
		
		ret:AddDamage(damage)
		
		ret:AddBounce(p1 + DIR_VECTORS[dir]*k,3)
		
	--	ret:AddSound(self.BombLaunchSound)
	end
	
	return ret
end

Brute_Bombrun_A = Brute_Bombrun:new{
	Limited = 2
}
Brute_Bombrun_B = Brute_Bombrun:new{
	Fire = 1,
	Acid = 1,
	Damage = 0
}
Brute_Bombrun_AB = Brute_Bombrun:new{
	Acid = 1,
	Fire = 1,
	Damage = 0,
	Limited = 2
}

----- Hermes Engines -----
-- Base cost reduced to Free from 1 --
Brute_Sonic.PowerCost = 0