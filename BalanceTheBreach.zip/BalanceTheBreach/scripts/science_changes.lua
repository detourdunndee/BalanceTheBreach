----- Attraction Pulse  -----
-- Base cost increased to 1 from Free --
-- New upgrade: Shield Self --

Science_Pullmech.PowerCost = 1
Science_Pullmech.Upgrades = 1
Science_Pullmech.UpgradeCost = {1}
		
function Science_Pullmech:GetSkillEffect(p1,p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2 - p1)
			
	local target = GetProjectileEnd(p1,p2)  
	
	
	local damage = SpaceDamage(target, self.Damage, GetDirection(p1 - p2))
	if Board:IsPawnTeam(target, TEAM_PLAYER) then
		damage.iShield = self.Shield
	elseif Board:IsPawnTeam(target, TEAM_ENEMY) then
		damage.iAcid = self.Acid
	end

	--ret.path = Board:GetSimplePath(p1, target)
	ret:AddProjectile(damage,"effects/shot_pull", NO_DELAY)
	
	local temp = p1 
	while temp ~= target  do 
		ret:AddDelay(0.05)
		ret:AddBounce(temp,-1)
		temp = temp + DIR_VECTORS[direction]
	end

	local selfDamage = SpaceDamage(p1,0)
	
	if self.ShieldSelf then
		selfDamage.iShield = 1
	end
		
	ret:AddDamage(selfDamage)

	return ret
end

Science_Pullmech_A = Science_Pullmech:new{
	ShieldSelf = true,
}
----- Grav Well -----
-- Base cost increased to 1 from Free --
Science_Gravwell.PowerCost = 1

----- Repulse  -----
-- Shield Self moved to Attraction Pulse --
-- Shield Friendly cost reduced to 1 --
Science_Repulse.Upgrades = 1
Science_Repulse.UpgradeCost = {1}

Science_Repulse_A = Science_Repulse:new{
	ShieldFriendly = true,
	TipImage = {
	Unit = Point(2,2),
	Target = Point(2,1),
	Enemy = Point(2,3),
	Friendly = Point(3,2),
	Building = Point(2,1)
	}
}

----- Teleporter -----
-- Base cost increased to 1 from 0 --
Science_Swap.PowerCost = 1 

----- A.C.I.D. Projector -----
-- Base cost increased to 1 from Free --
Science_AcidShot.PowerCost = 1

----- Confuse Shot -----
-- Base cost increased to 1 from Free --
Science_Confuse.PowerCost = 1 

----- Smoke Pellets -----
-- Base cost increased to 1 from Free --
Science_SmokeDefense.PowerCost = 1

----- Shield Projector -----
-- Upgrade 1 (+1 Use) replaced with Shield Self, cost reduced to 1 from 2 --
-- Upgrade 2 cost increased to 3 from 2 --
Science_Shield.UpgradeCost = {1,3}
function Science_Shield:GetSkillEffect(p1, p2)
	local ret = SkillEffect()
	local direction = GetDirection(p2-p1)
	local damage = SpaceDamage(p2,0)
	damage.iShield = 1
	--damage.sAnim = ""
	
	ret:AddArtillery(damage,"effects/shot_pull_U.png", NO_DELAY)
--	ret:AddDamage(damage)
	for i = DIR_START, DIR_END do
		damage.loc = p2 + DIR_VECTORS[i]
		damage.bHidePath = true
		if self.WideArea or i == direction then
			ret:AddArtillery(damage,"effects/shot_pull_U.png", NO_DELAY)--ret:AddDamage(damage)
		end
	end
	
	local selfDamage = SpaceDamage(p1,0)
	
	if self.ShieldSelf then
		selfDamage.iShield = 1
	end
		
	ret:AddDamage(selfDamage)

	return ret
end	

Science_Shield_A = Science_Shield:new{
	ShieldSelf = true
}
Science_Shield_AB = Science_Shield:new{
	ShieldSelf = true,
	WideArea = true
}

----- Fire Beam -----
-- Upgrade 1 (+1 Use) changed to Unlimited Use --
Science_FireBeam_A.Limited = 0

----- Push Beam -----
-- Base cost increased to 2 from 1 --
Science_PushBeam.PowerCost = 2